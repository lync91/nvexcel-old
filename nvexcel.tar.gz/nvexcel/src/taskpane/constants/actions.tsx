// Char converter
export const CHANGE_SRC_KEY = "CHANGE_SRC_KEY";
export const CHANGE_DESC_KEY = "CHANGE_DESC_KEY";